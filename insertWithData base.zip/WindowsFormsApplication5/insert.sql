create database prac


use prac 


create table sms(name varchar(max), last_name varchar(max),
dateofbirth varchar(max), gender varchar(10)  
);


select * from sms

--------- making procedure------------

create proc asd
@name varchar(max),
@last_name varchar(max),
@dateofbirth varchar(max),
@gender varchar(10)
as ------- as k through ismain value aynge means proce k zarye table m value arhi hai --------
insert into sms values(@name,@last_name,@dateofbirth,@gender);

