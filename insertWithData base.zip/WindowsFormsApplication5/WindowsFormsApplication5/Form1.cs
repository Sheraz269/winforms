﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApplication5.DataSet1TableAdapters;

namespace WindowsFormsApplication5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            _textName.Text = "";
            _textLName.Text = "";
            _textDOB.Text = "";
            
            


        }

        private void button1_Click(object sender, EventArgs e)
        {
            asdTableAdapter asd = new asdTableAdapter();
            String gender = "";
            if (radioMale.Checked)
            {
                gender = "Male";
            }
            else if(radioFemale.Checked)
            {
                gender = "female";
            }

            asd.GetData(_textName.Text, _textLName.Text, _textDOB.Text, gender);

            MessageBox.Show("Success");

        }
    }
}
