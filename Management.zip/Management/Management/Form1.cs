﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Management.DataSet1TableAdapters;

namespace Management
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void _lgBtn_Click(object sender, EventArgs e)
        {
            int br = 0;
            lgTableAdapter lg = new lgTableAdapter();
            DataTable dt = new DataTable();

            dt = lg.GetData();

            for(int i = 0 ; i <dt.Rows.Count ; i++)
            {
                if (_txtUsername.Text == dt.Rows[i]["userName"].ToString() )
                {
                    
                  if  (_txtPassword.Text == dt.Rows[i]["Password"].ToString())
                {

                    if (dt.Rows[i]["Desgination"].ToString() == "admin" )
                    { 
                    br = 1;
                    MessageBox.Show("Login SuccessFully");
                    MessageBox.Show("Welcome Admin");
                    break;
                    }
                    br = 3;
                    MessageBox.Show("Login SuccessFully");
                }
                else
                {

                    br = 2;       
                    MessageBox.Show("Password Not Correct");
                    break;
                }
            }
                else
                {
                   br = 0;
                   
                }
            }
           if(br == 0)
          {
              MessageBox.Show("Login not SuccessFull");
              
           }
           
            
            }

        private void _update_Click(object sender, EventArgs e)
        {
            updatTableAdapter up = new updatTableAdapter();
            up.GetData(_upPassword.Text, _upUserName.Text);
        }
        }
    }

