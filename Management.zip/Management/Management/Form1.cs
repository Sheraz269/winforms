﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Management.DataSet2TableAdapters;

namespace Management
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void _lgBtn_Click(object sender, EventArgs e)
        {
            int br = 0; // iski  her value k hisaab se alag procedure hay
            lgTableAdapter lg = new lgTableAdapter();
            DataTable dt = new DataTable();

            dt = lg.GetData();

            for(int i = 0 ; i <dt.Rows.Count ; i++)
            {
               if (_txtUsername.Text == dt.Rows[i]["name"].ToString() )
               {                    
                   if  (_txtPassword.Text == dt.Rows[i]["pasword"].ToString())
                   {
                        if (dt.Rows[i]["designation"].ToString() == "admin" )
                        { 
                        br = 1;
                        MessageBox.Show("Login SuccessFully");
                            inht obj = new inht();
                            obj.Show();
                            this.Hide();
                        break;
                        }
                    br =2;
                    MessageBox.Show("Login SuccessFully");
                    break;
                    }
                    else
                    {
                         br = 3;       
                         MessageBox.Show("Password Not Correct");
                         break;
                    }
                }
                else
                {
                    br = 4;
                    
                }
            }
            if(br == 4)
            {
                MessageBox.Show("Login not SuccessFull");  
            }
        }

        private void _update_Click(object sender, EventArgs e)
        {
            updTableAdapter up = new updTableAdapter();
            up.GetData( _upUserName.Text, _upPassword.Text, textBox1.Text);
        }
        }
    }

