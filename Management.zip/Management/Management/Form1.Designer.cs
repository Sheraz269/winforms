﻿namespace Management
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this._txtUsername = new System.Windows.Forms.TextBox();
            this._txtPassword = new System.Windows.Forms.TextBox();
            this._lgBtn = new System.Windows.Forms.Button();
            this._upUserName = new System.Windows.Forms.TextBox();
            this._upPassword = new System.Windows.Forms.TextBox();
            this._update = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // _txtUsername
            // 
            this._txtUsername.Location = new System.Drawing.Point(78, 55);
            this._txtUsername.Name = "_txtUsername";
            this._txtUsername.Size = new System.Drawing.Size(146, 20);
            this._txtUsername.TabIndex = 0;
            // 
            // _txtPassword
            // 
            this._txtPassword.Location = new System.Drawing.Point(78, 81);
            this._txtPassword.Name = "_txtPassword";
            this._txtPassword.PasswordChar = '*';
            this._txtPassword.Size = new System.Drawing.Size(146, 20);
            this._txtPassword.TabIndex = 1;
            // 
            // _lgBtn
            // 
            this._lgBtn.Location = new System.Drawing.Point(78, 107);
            this._lgBtn.Name = "_lgBtn";
            this._lgBtn.Size = new System.Drawing.Size(75, 23);
            this._lgBtn.TabIndex = 2;
            this._lgBtn.Text = "Login";
            this._lgBtn.UseVisualStyleBackColor = true;
            this._lgBtn.Click += new System.EventHandler(this._lgBtn_Click);
            // 
            // _upUserName
            // 
            this._upUserName.Location = new System.Drawing.Point(78, 176);
            this._upUserName.Name = "_upUserName";
            this._upUserName.Size = new System.Drawing.Size(146, 20);
            this._upUserName.TabIndex = 3;
            // 
            // _upPassword
            // 
            this._upPassword.Location = new System.Drawing.Point(78, 202);
            this._upPassword.Name = "_upPassword";
            this._upPassword.Size = new System.Drawing.Size(146, 20);
            this._upPassword.TabIndex = 4;
            // 
            // _update
            // 
            this._update.Location = new System.Drawing.Point(78, 228);
            this._update.Name = "_update";
            this._update.Size = new System.Drawing.Size(75, 23);
            this._update.TabIndex = 5;
            this._update.Text = "Update";
            this._update.UseVisualStyleBackColor = true;
            this._update.Click += new System.EventHandler(this._update_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(78, 150);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(146, 20);
            this.textBox1.TabIndex = 6;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(473, 363);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this._update);
            this.Controls.Add(this._upPassword);
            this.Controls.Add(this._upUserName);
            this.Controls.Add(this._lgBtn);
            this.Controls.Add(this._txtPassword);
            this.Controls.Add(this._txtUsername);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox _txtUsername;
        private System.Windows.Forms.TextBox _txtPassword;
        private System.Windows.Forms.Button _lgBtn;
        private System.Windows.Forms.TextBox _upUserName;
        private System.Windows.Forms.TextBox _upPassword;
        private System.Windows.Forms.Button _update;
        private System.Windows.Forms.TextBox textBox1;
    }
}

