create proc lg
as
Select * from Tble ;


create proc updat
@password varchar(50),
@username varchar(50)
as
Update Tble set Password = @password where userName = @username;