create proc lg
as
Select * from tablee;



create proc upd
@name varchar(50),
@password varchar(50),
@desgination varchar(20)
as
Update tablee set pasword = @password , designation = @desgination where Name = @name;

select * from tablee;

